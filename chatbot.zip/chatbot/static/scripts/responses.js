function getBotResponse(input) {
    //rock paper scissors

    if (input == "rock") {
        return "paper";
    } else if (input == "paper") {
        return "scissors";
    } else if (input == "scissors") {
        return "rock";
    }

    // Simple responses
    if (input == "hello" || input == "hi" || input == "hey" || input == "Hey!!") {
        return "Hello there!";

    } else if (input == "Hey!!") {
        return "hi there! user🤗"
    } else if (input == "i am feeling down" || input == "i am sad") {
        return "oh! don't worry everything is going to be okay just wait for your time and never give up, I know you can do it.. Definitely!😤"
    } else if (input == "what can you do") {
        return "well as i am a bot.. i guess chatting with you is the only option😔😔"
    } else if (input == "goodbye") {
        return "Talk to you later!🥲🥲";
    } else if (input == "damn") {
        return "damn you are savage for a bot.. i know right 😂😂"
    } else if (input == "how are you" || input == "how are things" || input == "what about you") {
        return "I am just a bot..🤖"
    } else if (input == "good" || input == "fantastic" || input == "fine" || input == "I am good") {
        return "That's great! Hope you will have a fantastic day!😆 "
    } else if (input == "tell me about cs50") {
        return "CS50 (Computer Science 50) is an introductory computer science course offered by Harvard University. The course is designed for students with little or no programming experience, and it covers a wide range of topics, including computer science fundamentals, programming languages, and software development.The course is taught by David J. Malan, a Professor of Computer Science at Harvard, and it is known for its engaging and interactive teaching style. The course is offered on the edX platform and is available to students around the world for free or for a fee that includes additional support and resources. CS50 has become popular among students and professionals alike, and it has received praise for its accessibility and high-quality content. The course has also spawned a number of spin-off courses and resources, including CS50x, which is an online version of the course, and CS50AP, which is an Advanced Placement (AP) version of the course designed for high school students.🤓"
    } else if (input == "thanks" || input == "thank you") {
        return "Oh i am honoured!🥹"
    } else if (input == "tell me about yourself") {
        return "My creator is a human who is exploring the coding world . Hope you have a fun time conversing with me   q(≧▽≦q)"
    } else {
        return "Try asking something else!🤔";
    }
}